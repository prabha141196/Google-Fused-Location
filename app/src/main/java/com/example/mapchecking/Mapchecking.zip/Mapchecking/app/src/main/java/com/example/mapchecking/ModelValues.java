package com.example.mapchecking;

public class ModelValues {
    String type;
    Double lat;
    Double lon;

    ModelValues() {}

    public ModelValues(String type, Double lat,Double lon) {
        this.type = type;
        this.lat = lat;
        this.lon = lon;
    }

    public String gettype() {
        return type;
    }

    public Double getlat() {
        return lat;
    }
    public Double getlon() {
        return lon;
    }
}
